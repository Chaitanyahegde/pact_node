import { AbstractService, LogLevel } from './service';
export declare class Server extends AbstractService {
    static create: (options?: ServerOptions | undefined) => Server;
    readonly options: ServerOptions;
    constructor(options?: ServerOptions);
}
declare const _default: (options?: ServerOptions | undefined) => Server;
export default _default;
export interface ServerOptions {
    port?: number;
    ssl?: boolean;
    cors?: boolean;
    dir?: string;
    host?: string;
    sslcert?: string;
    sslkey?: string;
    log?: string;
    spec?: number;
    consumer?: string;
    provider?: string;
    monkeypatch?: string;
    logLevel?: LogLevel;
    timeout?: number;
    pactFileWriteMode?: 'overwrite' | 'update' | 'merge';
}

"use strict";
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Message = void 0;
var fs = require("fs");
var q = require("q");
var logger_1 = require("./logger");
var spawn_1 = require("./spawn");
var spawn_2 = require("./spawn");
var pact_standalone_1 = require("./pact-standalone");
var path = require("path");
var mkdirp = require("mkdirp");
var checkTypes = require('check-types');
var Message = (function () {
    function Message(options) {
        this.__argMapping = {
            pactFileWriteMode: spawn_2.DEFAULT_ARG,
            dir: '--pact_dir',
            consumer: '--consumer',
            provider: '--provider',
            spec: '--pact_specification_version',
        };
        options = options || {};
        options.pactFileWriteMode = options.pactFileWriteMode || 'update';
        options.spec = options.spec || 3;
        checkTypes.assert.nonEmptyString(options.consumer, 'Must provide the consumer name');
        checkTypes.assert.nonEmptyString(options.provider, 'Must provide the provider name');
        checkTypes.assert.nonEmptyString(options.content, 'Must provide message content');
        checkTypes.assert.nonEmptyString(options.dir, 'Must provide pact output dir');
        if (options.spec) {
            checkTypes.assert.number(options.spec);
            checkTypes.assert.integer(options.spec);
            checkTypes.assert.positive(options.spec);
        }
        if (options.dir) {
            options.dir = path.resolve(options.dir);
            try {
                fs.statSync(options.dir).isDirectory();
            }
            catch (e) {
                mkdirp.sync(options.dir);
            }
        }
        if (options.content) {
            try {
                JSON.parse(options.content);
            }
            catch (e) {
                throw new Error('Unable to parse message content to JSON, invalid json supplied');
            }
        }
        if (options.consumer) {
            checkTypes.assert.string(options.consumer);
        }
        if (options.provider) {
            checkTypes.assert.string(options.provider);
        }
        this.options = options;
    }
    Message.prototype.createMessage = function () {
        logger_1.default.info("Creating message pact");
        var deferred = q.defer();
        var _a = this.options, pactFileWriteMode = _a.pactFileWriteMode, content = _a.content, restOptions = __rest(_a, ["pactFileWriteMode", "content"]);
        var instance = spawn_1.default.spawnBinary(pact_standalone_1.default.messageFullPath, [{ pactFileWriteMode: pactFileWriteMode }, restOptions], this.__argMapping);
        var output = [];
        instance.stdout.on('data', function (l) { return output.push(l); });
        instance.stderr.on('data', function (l) { return output.push(l); });
        instance.stdin.write(content);
        instance.once('close', function (code) {
            var o = output.join('\n');
            logger_1.default.info(o);
            if (code === 0) {
                return deferred.resolve(o);
            }
            else {
                return deferred.reject(o);
            }
        });
        instance.stdin.end();
        return deferred.promise;
    };
    return Message;
}());
exports.Message = Message;
exports.default = (function (options) { return new Message(options); });
//# sourceMappingURL=message.js.map
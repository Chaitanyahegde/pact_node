"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Arguments = exports.PACT_NODE_NO_VALUE = exports.DEFAULT_ARG = void 0;
var _ = require('underscore');
var checkTypes = require('check-types');
exports.DEFAULT_ARG = 'DEFAULT';
exports.PACT_NODE_NO_VALUE = 'PACT_NODE_NO_VALUE';
var valFor = function (v) {
    if (typeof v === 'object') {
        return [JSON.stringify(v)];
    }
    return v !== exports.PACT_NODE_NO_VALUE ? ["" + v] : [];
};
var mapFor = function (mapping, v) {
    return mapping === exports.DEFAULT_ARG
        ? valFor(v)
        : typeof mapping === 'string'
            ? [mapping].concat(valFor(v))
            : mapping(v);
};
var convertValue = function (mapping, v) {
    if (mapping && (v || typeof v === 'boolean')) {
        return checkTypes.array(v)
            ? _.flatten(v.map(function (val) { return mapFor(mapping, val); }))
            : mapFor(mapping, v);
    }
    return [];
};
var Arguments = (function () {
    function Arguments() {
    }
    Arguments.prototype.toArgumentsArray = function (args, mappings) {
        var _this = this;
        return _.chain(args instanceof Array ? args : [args])
            .map(function (x) { return _this.createArgumentsFromObject(x, mappings); })
            .flatten()
            .value();
    };
    Arguments.prototype.createArgumentsFromObject = function (args, mappings) {
        return _.chain(args)
            .reduce(function (acc, value, key) {
            return mappings[key] === exports.DEFAULT_ARG
                ? convertValue(mappings[key], value).concat(acc)
                : acc.concat(convertValue(mappings[key], value));
        }, [])
            .flatten()
            .compact()
            .value();
    };
    return Arguments;
}());
exports.Arguments = Arguments;
exports.default = new Arguments();
//# sourceMappingURL=arguments.js.map
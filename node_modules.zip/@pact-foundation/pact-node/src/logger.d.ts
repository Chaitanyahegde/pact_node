import pino = require('pino');
export declare type Logger = pino.Logger;
export declare type LogLevels = pino.Level;
declare const logger: pino.Logger;
export declare const setLogLevel: (wantedLevel?: number | pino.Level | undefined) => number | void;
export declare const verboseIsImplied: () => boolean;
export default logger;

import q = require('q');
import { LogLevel } from './service';
export declare class Verifier {
    static create: (options: VerifierOptions) => Verifier;
    readonly options: VerifierOptions;
    private readonly __argMapping;
    constructor(options: VerifierOptions);
    verify(): q.Promise<string>;
}
declare const _default: (options: VerifierOptions) => Verifier;
export default _default;
interface BrokenConsumerVersionSelectors {
    pacticipant?: string;
    version?: string;
    all?: boolean;
}
export interface ConsumerVersionSelector extends BrokenConsumerVersionSelectors {
    tag?: string;
    latest?: boolean;
    consumer?: string;
    deployedOrReleased?: boolean;
    deployed?: boolean;
    released?: boolean;
    environment?: string;
    fallbackTag?: string;
    branch?: string;
    mainBranch?: boolean;
    matchingBranch?: boolean;
}
interface CurrentVerifierOptions {
    providerBaseUrl: string;
    provider?: string;
    pactUrls?: string[];
    pactBrokerUrl?: string;
    pactBrokerUsername?: string;
    pactBrokerPassword?: string;
    pactBrokerToken?: string;
    consumerVersionTags?: string | string[];
    providerVersionTags?: string | string[];
    providerVersionBranch?: string;
    consumerVersionSelectors?: ConsumerVersionSelector[];
    customProviderHeaders?: string[];
    publishVerificationResult?: boolean;
    providerVersion?: string;
    enablePending?: boolean;
    timeout?: number;
    verbose?: boolean;
    includeWipPactsSince?: string;
    monkeypatch?: string;
    format?: 'json' | 'xml' | 'progress' | 'RspecJunitFormatter';
    out?: string;
    logDir?: string;
    logLevel?: LogLevel;
}
interface DeprecatedVerifierOptions {
    consumerVersionTag?: string | string[];
    providerStatesSetupUrl?: string;
    providerVersionTag?: string | string[];
    tags?: string[];
}
export declare type VerifierOptions = CurrentVerifierOptions & DeprecatedVerifierOptions;

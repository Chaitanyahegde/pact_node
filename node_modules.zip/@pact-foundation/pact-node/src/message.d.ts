import q = require('q');
export declare class Message {
    readonly options: MessageOptions;
    private readonly __argMapping;
    constructor(options: MessageOptions);
    createMessage(): q.Promise<unknown>;
}
declare const _default: (options: MessageOptions) => Message;
export default _default;
export interface MessageOptions {
    content?: string;
    dir?: string;
    consumer?: string;
    provider?: string;
    pactFileWriteMode?: 'overwrite' | 'update' | 'merge';
    spec?: number;
}

"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PactEnvironment = void 0;
var path = require("path");
var PactEnvironment = (function () {
    function PactEnvironment() {
    }
    Object.defineProperty(PactEnvironment.prototype, "cwd", {
        get: function () {
            return path.resolve(__dirname, '..');
        },
        enumerable: false,
        configurable: true
    });
    PactEnvironment.prototype.isWindows = function (platform) {
        if (platform === void 0) { platform = process.platform; }
        return platform === 'win32';
    };
    return PactEnvironment;
}());
exports.PactEnvironment = PactEnvironment;
exports.default = new PactEnvironment();
//# sourceMappingURL=pact-environment.js.map
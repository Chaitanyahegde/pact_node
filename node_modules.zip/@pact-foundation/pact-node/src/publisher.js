"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Publisher = void 0;
var q = require("q");
var path = require("path");
var fs = require("fs");
var logger_1 = require("./logger");
var spawn_1 = require("./spawn");
var spawn_2 = require("./spawn");
var util_1 = require("util");
var pact_standalone_1 = require("./pact-standalone");
var checkTypes = require('check-types');
var Publisher = (function () {
    function Publisher(options) {
        this.__argMapping = {
            pactFilesOrDirs: spawn_2.DEFAULT_ARG,
            pactBroker: '--broker-base-url',
            pactBrokerUsername: '--broker-username',
            pactBrokerPassword: '--broker-password',
            pactBrokerToken: '--broker-token',
            tags: '--tag',
            consumerVersion: '--consumer-app-version',
            verbose: '--verbose',
            buildUrl: '--build-url',
            branch: '--branch',
        };
        options = options || {};
        options.tags = options.tags || [];
        options.timeout = options.timeout || 60000;
        checkTypes.assert.nonEmptyString(options.pactBroker, 'Must provide the pactBroker argument');
        checkTypes.assert.nonEmptyString(options.consumerVersion, 'Must provide the consumerVersion argument');
        checkTypes.assert.arrayLike(options.pactFilesOrDirs, 'Must provide the pactFilesOrDirs argument');
        checkTypes.assert.nonEmptyArray(options.pactFilesOrDirs, 'Must provide the pactFilesOrDirs argument with an array');
        if (options.pactFilesOrDirs) {
            checkTypes.assert.array.of.string(options.pactFilesOrDirs);
            options.pactFilesOrDirs = options.pactFilesOrDirs.map(function (v) {
                var newPath = path.resolve(v);
                if (!fs.existsSync(newPath)) {
                    throw new Error("Path '" + v + "' given in pactFilesOrDirs does not exists.");
                }
                return newPath;
            });
        }
        if (options.pactBroker) {
            checkTypes.assert.string(options.pactBroker);
        }
        if (options.pactBrokerUsername) {
            checkTypes.assert.string(options.pactBrokerUsername);
        }
        if (options.pactBrokerPassword) {
            checkTypes.assert.string(options.pactBrokerPassword);
        }
        if (options.verbose === undefined && (0, logger_1.verboseIsImplied)()) {
            options.verbose = true;
        }
        if ((options.pactBrokerUsername && !options.pactBrokerPassword) ||
            (options.pactBrokerPassword && !options.pactBrokerUsername)) {
            throw new Error('Must provide both Pact Broker username and password. None needed if authentication on Broker is disabled.');
        }
        if (options.pactBrokerToken &&
            (options.pactBrokerUsername || options.pactBrokerPassword)) {
            throw new Error('Must provide pactBrokerToken or pactBrokerUsername/pactBrokerPassword but not both.');
        }
        this.options = options;
    }
    Publisher.prototype.publish = function () {
        logger_1.default.info("Publishing pacts to broker at: " + this.options.pactBroker);
        var deferred = q.defer();
        var instance = spawn_1.default.spawnBinary(pact_standalone_1.default.brokerFullPath, [{ cliVerb: 'publish' }, this.options], this.__argMapping);
        var output = [];
        instance.stdout.on('data', function (l) { return output.push(l); });
        instance.stderr.on('data', function (l) { return output.push(l); });
        instance.once('close', function (code) {
            var o = output.join('\n');
            var pactUrls = /https?:\/\/.*\/pacts\/.*$/gim.exec(o);
            if (code !== 0) {
                var message = "Pact publication failed with non-zero exit code. Full output was:\n" + o;
                logger_1.default.error(message);
                return deferred.reject(new Error(message));
            }
            if (!pactUrls) {
                var message = "Publication appeared to fail, as we did not detect any pact URLs in the following output:\n" + o;
                logger_1.default.error(message);
                return deferred.reject(new Error(message));
            }
            logger_1.default.info(o);
            return deferred.resolve(pactUrls);
        });
        return deferred.promise.timeout(this.options.timeout, "Timeout waiting for verification process to complete (PID: " + instance.pid + ")");
    };
    Publisher.create = (0, util_1.deprecate)(function (options) { return new Publisher(options); }, 'Create function will be removed in future release, please use the default export function or use `new Publisher()`');
    return Publisher;
}());
exports.Publisher = Publisher;
exports.default = (function (options) { return new Publisher(options); });
//# sourceMappingURL=publisher.js.map
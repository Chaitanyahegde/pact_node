/// <reference types="node" />

declare module 'sbffi' {
  export function getNativeFunction(libPath: string, functionName: string, returnType: string, arguments: string[]): any
}
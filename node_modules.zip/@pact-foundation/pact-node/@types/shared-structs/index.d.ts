/// <reference types="node" />

declare module 'shared-structs/require';
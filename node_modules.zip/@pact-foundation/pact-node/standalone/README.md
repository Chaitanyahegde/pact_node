# Standalone binaries

This folder is automatically populated during build by /script/download-standalone.sh

# FFI

## Node GYP

## Docker

Build time dependencies

* Python
* Make
* C++ Build tool chain

### Ubuntu

TBC

### Alpine

TODO: don't currently have pact reference Alpine artifacts

See also: https://dustri.org/b/error-loading-shared-library-ld-linux-x86-64so2-on-alpine-linux.html

I think we need a glibc shared library

```docker
FROM node:16-alpine
EXPOSE 8080
WORKDIR /app
COPY . .
RUN apk add --no-cache --virtual .gyp \
        python \
        make \
        g++ \
    && npm install \
    && apk del .gyp
CMD ["npm", "start"]
```

## Packaging

### OSX



### Linux

The linux dis

```
readelf -d build/Release/pact.node | grep libpact_ffi
 0x0000000000000001 (NEEDED)             Shared library: [libpact_ffi.so]
 ```

 The library has embedded runpath to discover `libpact_ffi.so` in the `<package_root>/build/Release/ffi` folder at runtime relative to the `pact.node` distribution.

 ```
 readelf -d build/Release/pact.node | grep run
 0x000000000000001d (RUNPATH)            Library runpath: [$ORIGIN/ffi]
 ```

### Windows

DLL is distributed into the `<package_root>/build/Release` directory.

The DLL file will be discovered in the location of the executing library as per: https://docs.microsoft.com/en-us/windows/win32/dlls/dynamic-link-library-search-order#search-order-for-desktop-applications
export default class GraphQLQueryError extends Error {
}

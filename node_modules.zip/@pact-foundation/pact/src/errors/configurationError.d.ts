export default class ConfigurationError extends Error {
}

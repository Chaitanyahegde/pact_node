export default class VerificationError extends Error {
}

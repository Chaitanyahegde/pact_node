export default class MatcherError extends Error {
}

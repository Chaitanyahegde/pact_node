import { GraphQLInteraction } from "./graphql";
export declare class ApolloGraphQLInteraction extends GraphQLInteraction {
    constructor();
}

import * as q from "q";
export declare function qToPromise<T>(promise: q.Promise<T>): Promise<T>;
